package com.bjsxt.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bjsxt.App;
import com.bjsxt.pojo.Users;
import com.bjsxt.service.UsersService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes=App.class)
public class UsersServiceTest {
	@Autowired
	private UsersService usersService;
	@Test
	public void testFindUsersById(){
		System.out.println(this.usersService.findUserById(2));
		System.out.println(this.usersService.findUserById(2));
	}
	@Test
	public void testFindUserByPage(){
		Pageable pageable=new PageRequest(1,1);
		System.out.println(this.usersService.findUserByPage(pageable).getTotalElements());
		System.out.println(this.usersService.findUserByPage(pageable).getTotalElements());
		pageable=new PageRequest(0, 1);
		System.out.println(this.usersService.findUserByPage(pageable).getTotalElements());
	}
	@Test
	public void findUsersAll(){
		System.out.println(this.usersService.findUserAll().size());
		
		Users user=new Users();
		user.setName("朱琪");
		user.setAge(15);
		user.setAddress("南京");
		this.usersService.saveUsers(user);
		
		System.out.println(this.usersService.findUserAll().size());
	}
}
