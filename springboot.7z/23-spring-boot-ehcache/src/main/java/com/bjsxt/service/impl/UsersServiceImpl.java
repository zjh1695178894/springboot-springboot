package com.bjsxt.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.bjsxt.dao.UsersRepository;
import com.bjsxt.pojo.Users;
import com.bjsxt.service.UsersService;
@Service
public class UsersServiceImpl implements UsersService{
	@Autowired
	private UsersRepository usersRepository;
	@Override
	@Cacheable(value="users")
	public List<Users> findUserAll() {
		// TODO Auto-generated method stub
		return this.usersRepository.findAll();
	}

	@Override
	@Cacheable(value="users")
	public Users findUserById(Integer id) {
		// TODO Auto-generated method stub
		return this.usersRepository.findOne(id);
	}

	@Override
	//到底从不从缓存取数据取决于key,key表示基于什么去判断是否查询缓存
	@Cacheable(value="users",key="#pageable.pageSize")
	public Page<Users> findUserByPage(Pageable pageable) {
		// TODO Auto-generated method stub
		return this.usersRepository.findAll(pageable);
	}

	@Override
	//清除缓存
	@CacheEvict(value="users",allEntries=true)
	public void saveUsers(Users users) {
		// TODO Auto-generated method stub
		this.usersRepository.save(users);
	}
}
