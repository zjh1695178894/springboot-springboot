package com.sxt.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.scheduling.quartz.SimpleTriggerFactoryBean;

import com.sxt.quartz.QuartzDemo;

@Configuration
public class QuartzConfig {
	//创建Job对象
	@Bean
	public JobDetailFactoryBean jobDetailFactoryBean(){
		JobDetailFactoryBean job=new JobDetailFactoryBean();
		//关联已有job类
		job.setJobClass(QuartzDemo.class);
		return job;
	}
	//创建Trigger对象
	/*@Bean
	public SimpleTriggerFactoryBean simpleTriggerFactoryBean(JobDetailFactoryBean jobDetailFactoryBean){
		SimpleTriggerFactoryBean trigger=new SimpleTriggerFactoryBean();
		//关联JobDetail对象
		trigger.setJobDetail(jobDetailFactoryBean.getObject());
		//设置执行的间隔毫秒数
		trigger.setRepeatInterval(1000);
		//设置执行的次数
		trigger.setRepeatCount(5);
		return trigger;
	}*/
	@Bean 
	public CronTriggerFactoryBean cronTriggerFactoryBean(JobDetailFactoryBean jobDetailFactoryBean){ 
		CronTriggerFactoryBean factory = new CronTriggerFactoryBean(); 
		factory.setJobDetail(jobDetailFactoryBean.getObject()); 
		//设置触发时间 
		factory.setCronExpression("0/2 * * * * ?"); 
		return factory; 
	}

	//创建scheduled对象
	@Bean
	public SchedulerFactoryBean schedulerFactoryBean(CronTriggerFactoryBean cronTriggerFactoryBean,MyAdaptableJobFactory myAdaptableJobFactory){
		SchedulerFactoryBean schedule=new SchedulerFactoryBean();
		schedule.setTriggers(cronTriggerFactoryBean.getObject());
		schedule.setJobFactory(myAdaptableJobFactory);
		return schedule;
	}
}
