package com.sxt.service;

import org.springframework.stereotype.Service;

@Service
public class UsersService {
	public void addUser(){
		System.out.println("add User =====");
	}
}
