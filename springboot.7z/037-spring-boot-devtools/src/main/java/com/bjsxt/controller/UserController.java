package com.bjsxt.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class UserController {
	@RequestMapping("/show")
	public String showpage(){
		System.out.println("init-springboot=aa");
		return "index";
	}
}
