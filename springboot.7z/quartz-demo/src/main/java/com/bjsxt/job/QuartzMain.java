package com.bjsxt.job;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

public class QuartzMain {

	public static void main(String[] args) throws SchedulerException {
		// TODO Auto-generated method stub
			//1.创建job对象：做什么
		JobDetail build = JobBuilder.newJob(QuartzDemo.class).build();
			//2.创建Trigger对象：什么时间做
		Trigger trigger = TriggerBuilder.newTrigger().withSchedule(CronScheduleBuilder.cronSchedule("0/2 * * * * ?")).build();
			//3.创建Scheduled对象：什么时间做什么事
		Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
		scheduler.scheduleJob(build, trigger);
		scheduler.start();
	}

}
