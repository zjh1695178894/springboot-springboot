package com.bjsxt.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import redis.clients.jedis.JedisPoolConfig;

@Configuration
public class RedisConfig {
	@Bean
	@ConfigurationProperties(prefix="spring.redis.pool")
	public JedisPoolConfig jedisPoolConfig(){
		JedisPoolConfig config=new JedisPoolConfig();
		/*//设置最大和最小空闲数
		config.setMaxIdle(10);
		config.setMinIdle(5);
		//设置最大连接数
		config.setMaxTotal(20);*/
		return config;
	}
	@Bean
	@ConfigurationProperties(prefix="spring.redis")
	public JedisConnectionFactory JedisConnectionFactory(JedisPoolConfig jedisPoolConfig){
		JedisConnectionFactory factory=new JedisConnectionFactory();
		factory.setPoolConfig(jedisPoolConfig);
		/*factory.setHostName("192.168.157.129");
		factory.setPort(6379);*/
		return factory;
	}
	@Bean
	public RedisTemplate<String,Object> jedisTemplate(JedisConnectionFactory factory){
		RedisTemplate<String,Object> template=new RedisTemplate<>();
		template.setConnectionFactory(factory);
		//为redis的key和value设置序列化器
		template.setKeySerializer(new StringRedisSerializer());
		template.setValueSerializer(new StringRedisSerializer());
		return template;
		
	}
}
