package com.bjsxt.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.App;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes=App.class)
public class RedisTest {
	@Autowired
	private RedisTemplate<String,Object> redisTemplate;
	@Test
	public void TestSet(){
		this.redisTemplate.opsForValue().set("key", "test");
	}
	@Test
	public void TestGet(){
		String str=(String) this.redisTemplate.opsForValue().get("key");
		System.out.println(str);
	}
}
