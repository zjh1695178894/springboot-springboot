package com.sxt.mapper;

import java.util.List;

import com.sxt.pojo.Users;

public interface UsersMapper {
	void insertUser(Users users);
	List<Users> selectUsersAll();
	Users SelectUserById(Integer id);
	void updateUser(Users user);
	void deleteUser(Integer id);
}
