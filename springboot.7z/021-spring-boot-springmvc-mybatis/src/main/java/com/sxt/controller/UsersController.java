package com.sxt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sxt.pojo.Users;
import com.sxt.service.UsersService;

@Controller
@RequestMapping("/users")
public class UsersController {
	@Autowired
	private UsersService usersService;
	
	@RequestMapping("/{page}")
	public String showPage(@PathVariable String page){
		return page;
	}
	@RequestMapping("/addUser")
	public String addUser(Users users){
		this.usersService.addUser(users);
		return "ok";
	}
	@RequestMapping("/findUsersAll")
	public String findUsersAll(Model model){
		List<Users> list=usersService.selectUsersAll();
		model.addAttribute("list", list);
		return "showUsers";
	}
	@RequestMapping("/findUserById")
	public String findUserById(Integer id,Model model){
		Users user = this.usersService.finduserById(id);
		model.addAttribute("user", user);
		return "updateUser";
	}
	@RequestMapping("/editUser")
	public String updateUser(Users user){
		this.usersService.updateUser(user);
		return "ok";
	}
	@RequestMapping("/deleteUser")
	public String deleteUser(Integer id){
		this.usersService.deleteUser(id);
		return "redirect:/users/findUsersAll";
	}
}
