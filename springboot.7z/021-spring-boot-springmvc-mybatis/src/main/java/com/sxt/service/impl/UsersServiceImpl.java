package com.sxt.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sxt.mapper.UsersMapper;
import com.sxt.pojo.Users;
import com.sxt.service.UsersService;
@Service
@Transactional
public class UsersServiceImpl implements UsersService {
	@Autowired
	private UsersMapper usersmapper;
	@Override
	public void addUser(Users user) {
		// TODO Auto-generated method stub
		this.usersmapper.insertUser(user);
	}
	@Override
	public List<Users> selectUsersAll() {
		return this.usersmapper.selectUsersAll();
	}
	@Override
	public Users finduserById(Integer id) {
		// TODO Auto-generated method stub
		return this.usersmapper.SelectUserById(id);
	}
	@Override
	public void updateUser(Users user) {
		// TODO Auto-generated method stub
		this.usersmapper.updateUser(user);
	}
	@Override
	public void deleteUser(Integer id) {
		// TODO Auto-generated method stub
		this.usersmapper.deleteUser(id);
	}

}
