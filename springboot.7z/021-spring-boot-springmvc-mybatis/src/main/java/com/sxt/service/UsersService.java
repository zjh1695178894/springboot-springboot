package com.sxt.service;

import java.util.List;

import com.sxt.pojo.Users;

public interface UsersService {
	void addUser(Users user);
	List<Users> selectUsersAll();
	Users finduserById(Integer id);
	void updateUser(Users user);
	void deleteUser(Integer id);
}
