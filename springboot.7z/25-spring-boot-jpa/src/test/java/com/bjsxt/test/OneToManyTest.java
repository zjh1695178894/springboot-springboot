package com.bjsxt.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bjsxt.App;
import com.bjsxt.dao.UsersRepository;
import com.bjsxt.pojo.Roles;
import com.bjsxt.pojo.Users;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes=App.class)
public class OneToManyTest {
	@Autowired
	private UsersRepository usersRepository;
	@Test
	public void testSave(){
		Users user=new Users();
		user.setName("张晓峰");
		user.setAge(55);
		user.setAddress("大学");
		
		Roles role=new Roles();
		role.setRolename("管理员");
		
		role.getUsers().add(user);
		user.setRoles(role);
		
		this.usersRepository.save(user);
	}
	@Test
	public void testFind(){
		Users one = this.usersRepository.findOne(6);
		System.out.println(one);
	}
}
