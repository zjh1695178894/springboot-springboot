package com.bjsxt.test;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bjsxt.App;
import com.bjsxt.dao.UsersCrudRepository;
import com.bjsxt.dao.UsersRepository;
import com.bjsxt.dao.UsersRepositoryByName;
import com.bjsxt.dao.UsersRepositoryPageAndSort;
import com.bjsxt.dao.UsersRepositoryQueryAnnotation;
import com.bjsxt.dao.UsersRepositorySpecification;
import com.bjsxt.pojo.Users;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes=App.class)
public class UsersRepositoryTest {
	@Autowired
	private UsersRepository usersRepository;
	@Autowired
	private UsersRepositoryByName usersRepositoryByName;
	@Autowired
	private UsersRepositoryQueryAnnotation usersRepositoryQueryAnnotation;
	@Autowired
	private UsersCrudRepository usersCrudRepository;
	@Autowired
	private UsersRepositoryPageAndSort usersRepositoryPageAndSort;
	@Autowired
	private UsersRepositorySpecification usersRepositorySpecification;
	@Test
	public void save(){
		Users user=new Users();
		user.setName("赵武柳");
		user.setAge(18);
		user.setAddress("百万巨星");
		this.usersRepository.save(user);
	}
	@Test
	public void testFindByName(){
		List<Users> list = this.usersRepositoryByName.findByNameIs("赵武柳");
		for(Users user:list){
			System.out.println(user);
		}
	}
	@Test
	public void testFindByNameAndAge(){
		List<Users> list = this.usersRepositoryByName.findByNameAndAge("赵武柳", 18);
		for(Users user:list){
			System.out.println(user);
		}
	}
	@Test
	public void testQueryByNameUserHQL(){
		List<Users> list = this.usersRepositoryQueryAnnotation.queryByNameUserHQL("赵武柳");
		for(Users user:list){
			System.out.println(user);
		}
	}
	@Test
	public void testQueryByNameUserSQL(){
		List<Users> list = this.usersRepositoryQueryAnnotation.queryByNameUserSQL("赵武柳");
		for(Users user:list){
			System.out.println(user);
		}
	}
	@Test
	@Transactional
	@Rollback(false)
	public void testUpdateUsersNameById(){
		this.usersRepositoryQueryAnnotation.updateUsersNameById("赵武柳liu",1);
	}
	@Test
	public void testCrudRepositorySave(){
		Users user=new Users();
		user.setName("李长荣");
		user.setAge(65);
		user.setAddress("秧歌start");
		this.usersCrudRepository.save(user);
	}
	@Test
	public void testPage(){
		Order order=new Order(Direction.DESC,"id");
		Sort sort=new Sort(order);
		List<Users> list= (List<Users>) this.usersRepositoryPageAndSort.findAll(sort);
		for(Users user:list){
			System.out.println(user);
		}
	}
	@Test
	public void testSort(){
		Pageable pageable=new PageRequest(2, 2);
		Page<Users> page = this.usersRepositoryPageAndSort.findAll(pageable);
		System.out.println("总条数"+page.getTotalElements());
		System.out.println("总页数"+page.getTotalPages());
		for(Users user:page){
			System.out.println(user);
		}
	}
	@Test
	public void testPageAndSort(){
		Sort sort=new Sort(new Order(Direction.DESC,"id"));
		Pageable page=new PageRequest(0, 2,sort);
		Page<Users> page2 = this.usersRepositoryPageAndSort.findAll(page);
		System.out.println("总条数"+page2.getTotalElements());
		System.out.println("总页数"+page2.getTotalPages());
		for(Users user:page2){
			System.out.println(user);
		}
	}
	@Test
	public void testSpecification1(){
		Specification<Users> spec=new Specification<Users>() {
			
			@Override
			public Predicate toPredicate(Root<Users> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Predicate pre = cb.equal(root.get("name"),"张无忌");
				return pre;
			}
		};
		List<Users> list = this.usersRepositorySpecification.findAll(spec);
		for(Users user:list){
			System.out.println(user);
		}
	}
	@Test
	public void testSpecification2(){
		Specification<Users> spec=new Specification<Users>() {
			
			@Override
			public Predicate toPredicate(Root<Users> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				List<Predicate> list=new ArrayList<>();
				list.add(cb.equal(root.get("name"), "张无忌"));
				list.add(cb.equal(root.get("age"), 42));
				Predicate[] arr = new Predicate[list.size()];
				return cb.and(list.toArray(arr));
			}
		};
		List<Users> list = this.usersRepositorySpecification.findAll(spec);
		for(Users user:list){
			System.out.println(user);
		}
	}
	@Test
	public void testSpecification3(){
		Specification<Users> spec=new Specification<Users>() {
			
			@Override
			public Predicate toPredicate(Root<Users> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				/*List<Predicate> list=new ArrayList<>();
				list.add(cb.equal(root.get("name"), "张无忌"));
				list.add(cb.equal(root.get("age"), 42));
				Predicate[] arr = new Predicate[list.size()];*/
				return cb.and(cb.equal(root.get("name"), "张无忌"),cb.equal(root.get("age"), 42));
			}
		};
		List<Users> list = this.usersRepositorySpecification.findAll(spec);
		for(Users user:list){
			System.out.println(user);
		}
	}
}
