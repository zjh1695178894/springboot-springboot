package com.bjsxt.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.bjsxt.App;
import com.bjsxt.dao.RolesRepository;
import com.bjsxt.pojo.Menu;
import com.bjsxt.pojo.Roles;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes=App.class)
public class ManyToManyTest {
	@Autowired
	private RolesRepository rolesRepository;
	@Test
	public void testSave(){
		Roles role=new Roles();
		role.setRolename("超级管理员");
		
		Menu menu1=new Menu();
		menu1.setFatherid(-1);
		menu1.setMenuname("用户菜单");
		Menu menu2=new Menu();
		menu2.setFatherid(0);
		menu2.setMenuname("查找功能");
		
		role.getMenus().add(menu1);
		role.getMenus().add(menu2);
		menu1.getRoles().add(role);
		menu2.getRoles().add(role);
		
		this.rolesRepository.save(role);
	}
}
