package com.bjsxt.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

import com.bjsxt.pojo.Users;

public interface UsersRepositoryQueryAnnotation extends Repository<Users, Integer> {
	@Query("from Users where name = ?")
	List<Users> queryByNameUserHQL(String name);
	@Query(value="select * from t_user where name = ?",nativeQuery=true)
	List<Users> queryByNameUserSQL(String name);
	@Query("update Users set name = ? where id = ?")
	@Modifying
	void updateUsersNameById(String name,Integer id);
}
