package com.bjsxt.dao;

import org.springframework.data.repository.CrudRepository;

import com.bjsxt.pojo.Users;

public interface UsersCrudRepository extends CrudRepository<Users,Integer> {

}
