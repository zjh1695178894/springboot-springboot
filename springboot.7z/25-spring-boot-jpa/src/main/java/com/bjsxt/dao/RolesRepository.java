package com.bjsxt.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bjsxt.pojo.Roles;

public interface RolesRepository extends JpaRepository<Roles,Integer> {

}
