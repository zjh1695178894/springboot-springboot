package com.bjsxt.dao;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.bjsxt.pojo.Users;

public interface UsersRepositoryPageAndSort extends PagingAndSortingRepository<Users, Integer> {

}
