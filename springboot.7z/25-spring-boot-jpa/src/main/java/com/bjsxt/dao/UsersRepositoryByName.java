package com.bjsxt.dao;

import java.util.List;

import org.springframework.data.repository.Repository;

import com.bjsxt.pojo.Users;

public interface UsersRepositoryByName extends Repository<Users,Integer> {
	List<Users> findByNameIs(String name);
	List<Users> findByNameAndAge(String name,Integer age);
}
